# OCI Generative AI Agents - Customer Support Agent Helper Demo

The demo showcases:

1. The Agents platform.
1. SQL Tool.
1. RAG Tool.
1. Custom Tool.
1. Autonomous Database.
1. Generative AI (as a means of generating synthetic data for the database as well as knowledge articles).

Please checkout the full [demo video](https://otube.oracle.com/media/t/1_c50g3gc1).

## Prerequisites

1. Access to a tenancy & full access to the Generative AI Agents service. See [Service policies](https://docs.oracle.com/en-us/iaas/Content/generative-ai-agents/iam-policies.htm).
1. A node.js development environment - `v20+` required.
1. An autonomous database instance.

## Setup

1. Go into the `frontend` folder and run `npm install`.
1. Do the same for the `backend` folder.
1. Use [create-db.sql](./sql/create-db.sql) to create the database schema.
1. Use the JSON files in [./sql/data/](./sql/data) to load data into the database.
1. Upload the PDFs in [./knowledge-articles/](./knowledge-articles/) to a storage bucket in your tenancy.
1. [Create an agent](https://docs.oracle.com/en-us/iaas/Content/generative-ai-agents/create-agent.htm#create-agent).
1. [Create a SQL](https://docs.oracle.com/en-us/iaas/Content/generative-ai-agents/sqltool-add.htm#sqltool-create) tool in the agent.

   1. For the table schema, copy & paste the contents of [create-db.sql](./sql/create-db.sql).
   1. For the column tables and column descriptions use:

      ```text
      Customers table - Each record in this table contains information about a customer which may or may not have created a support ticket
      Columns:
      CustomerID - number, a unique identifier for the customer
      FirstName - string, the customer's first name
      LastName - string, the customer's last name
      Email - string, the customer's email for communications
      Phone - string, the customer's phone for communications
      Address - string - the customer's address for communications

      SupportAgents table - Each in this table contains information about a support agent which handles support tickets
      Columns:
      AgentID - number, a unique identifier for the support agent
      FirstName - string, the support agent's first name
      LastName - string, the support agent's last name
      Email - string, the support agent's work email
      Phone - string, the support agent's work phone

      TicketStatus table - Contains a list of possible statuses a support ticket can be in
      Columns:
      StatusID - number, a unique identifier for the status
      StatusName - string, the name assigned to the status
      The possible status names are:
      New - When a support ticket is initially created and before it was triaged
      Open - When the support ticket is triaged and assigned to a support agent
      In Progress - When the support agent started working on the issue
      On Hold - When an issue's resolution is delayed by an external factor or another issue
      Resolved - When an issue has been successfully resolved to the customer's satisfaction
      Closed - When the customer acknowledged the issue is resolved
      Escalated - When an issue could not be resolved by a support agent or if an issue has been active for more than 3 days
      Cancelled - When a customer reports that an issue has been resolved but no action was taken by the support agent

      Tickets table - Each record in this table contains information about an issue reported by a customer alongside information about the issue as well as the status
      this is issue is currently in and the support agent assigned to handle the issue.
      Columns:
      TicketID - number, a unique identifier for the ticket
      CustomerID - number, a customer ID from the Customers table representing the customer that reported the issue
      Subject - string, a short description of the issue
      Description - string, a full description of the issue, contains all of the information required to understand and address the issue
      CreatedDate - datetime, the date and time at which the ticket was created by the customer
      LastUpdatedDate - datetime, the date and time of the last action taken by a support agent regarding this ticket
      StatusID - number, a status ID from the TicketStatus table representing the current state or status of the ticket
      AssignedToAgentID - number, a support agent ID from the SupportAgents table representing the support agent assigned to handle the ticket
      SubjectVector - vector, a vectorized version of the subject column. Never return this column in select statements.
      DescriptionVector - vector, a vectorized version of the description column. Never return this column in select statements.

      Comments table - Contains comments created by support agent regarding a specific ticket. Represents a thread of communication between the support
      agent and the customer regarding the ticket.
      Columns:
      CommentID - number, a unique identifier for the comment
      TicketID - number, a ticket ID from the Tickets table representing the ticket the current comment was made about
      CommentText - string, the full text of the comment
      CreatedBy - number, a support agent ID from the SupportAgents table, representing the support agent that created the ticket
      CreatedDate - datetime, represents the date and time at which the comment was created
      ```

   1. Model customization - Large.
   1. In-context learning examples - Keep empty.
   1. Enable SQL execution & Self correction.
   1. No custom instructions.

1. [Create a RAG tool](https://docs.oracle.com/en-us/iaas/Content/generative-ai-agents/RAG-tool-create.htm#RAG-tool-create).

   1. Use the storage bucket to which you've uploaded the knowledge article PDFs as the knowledge base.

1. [Create a custom (function calling) tool](https://docs.oracle.com/en-us/iaas/Content/generative-ai-agents/function-calling-tool-create.htm#function-calling-tool-create)

   1. Use the following function parameters:

      ```json
      {
        "type": "object",
        "properties": {
          "customerEmail": {
            "description": "The email for the customer who created a support ticket.",
            "type": "string"
          },
          "subject": {
            "description": "The email subject, would typically contain the subject and ID of the ticket discussed.",
            "type": "string"
          },
          "emailBodyContent": {
            "description": "The email main content, will contain the actual reply from the customer support agent.",
            "type": "string"
          },
          "required": [
            "customerEmail",
            "subject",
            "emailBodyContent"
          ]
        },
        "additionalProperties": false
      }
      ```

1. Update the [.env](../backend/.env) file:

   1. Update `AGENT_ENDPOINT_OCID` with the agent **endpoint** OCID (not agent OCID, the endpoint OCID) you've created above.
   1. Update `AUTHENTICATION_PROFILE` profile to the profile you would like to use from you `~/.oci/config` file.
   1. If you're using this demo while on VPN, update `USE_PROXY` to `1`.

1. If you are running the demo on an OCI compute instance running Oracle Linux, you will have to enable traffic on TCP ports `3000` and `4000`, both on the machine itself and the VCN used for the compute instance. Use the following commands in the machine:

   ```bash
   sudo firewall-cmd --permanent --add-port=4000/tcp
   sudo firewall-cmd --permanent --add-port=3000/tcp
   sudo firewall-cmd --reload
   ```

1. Run `npm install -g typescript` to install typescript. You may have to run this command with `sudo` as it tried to globally install the package instead of installing it in your local folder.
1. Run `npm install` in [/backend](/backend/)
1. Run `npm install` in [/frontend](/frontend/)
1. Run `npm start` in [/backend](/backend/). This will run a webserver for the backend at `http://[you ip address]:3000`. Make sure no errors show in the prompt.
1. Run `npm start` in [/frontend](/frontend/). This will run a webserver for the frontend at `http://[you ip address]:4000`. Make sure no errors show in the prompt.
1. Open a browser to `http://[you ip address]:4000`.
1. If all is well, you should see the Agent's greeting message.
