import { css } from "@linaria/core";

import HelpIcon from "./icons/help";
import SupportTickets from "./pages/agent-chat";

export const globalStyles = css`
  :global() {
    html {
      box-sizing: border-box;
    }

    body {
      margin: 0;
    }
  }
`;

const appStyle = css`
  display: flex;
  font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  flex-direction: column;
  font-size: 0.75rem;

  hr {
    width: 100%;
    height: 1px;
    background-color: #e4e4e7;
    border: 0;
  }

  h3 {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding-left: 1rem;
  }
`;

const helpIconStyle = css`
  stroke: black;
  display: inline-block;
`;

export default function App() {
  return (
    <div className={appStyle}>
      <h3><HelpIcon className={helpIconStyle} /> Customer Support Agent</h3>
      <hr />
      <SupportTickets />
    </div>
  );
}