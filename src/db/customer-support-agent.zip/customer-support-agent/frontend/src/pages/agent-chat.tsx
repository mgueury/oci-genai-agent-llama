import { useState, useEffect, KeyboardEvent } from "react";
import axios from "axios";
import { css } from "@linaria/core";

import CommandHistory from "../utils/command-history";

import DataTable from "./components/data-table";
import Record from "./components/record";
import TextResponse from "./components/text-response";
import Email, { EmailInfo } from "./components/email";
import LoadingSpinner from "./components/loading-spinner";

export interface Citation {
  sourceText: string;
  sourceLocation: {
    url: string;
  },
  title: string;
  pageNumbers: number[];
}

export interface ChatMessage {
  type: "user" | "agent",
  message?: string | undefined;
  dataTable?: object[] | undefined;
  citations?: Citation[] | undefined;
}

const pageStyle = css`
  display: flex;
  width: 100%;
  padding: 1rem;
  box-sizing: border-box;
`;

const chatBoxStyle = css`
  display: flex;
  box-sizing: border-box;
  flex-direction: column;
  height: calc(100vh - 6.1rem);
  gap: 1rem;
  width: 100%;
`;

const chatHistoryStyle = css`
  box-sizing: border-box;
  display: flex;
  height: calc(100% - 1rem);
  flex-direction: column;
  overflow-y: auto;
  padding-right: 0.5rem;
`;

const chatInputContainerStyle = css`
  display: flex;
  gap: 0.5rem;
`;

const chatInputStyle = css`
  width: 100%;
  height: 1rem;
  padding: 1rem;
  border: none;
  border-radius: 0.75rem;
  border: 1px solid #e4e4e7;
  box-shadow: 1px 1px 1px #eee;
  font-size: 1rem;
`;

const chatButtonStyle = css`
  align-self: center;
  width: 5rem;
  padding: 0.7rem;
  font-size: 16px;
  border: none;
  border-radius: 1rem;
  background-color: #007bff;
  color: transparent;
  text-shadow: 0 0 0 #fff;
  cursor: pointer;

  div {
    transform:scale(1.5, 1);
  }
`;

const bubbleStyle = {
  display: "flex",
  padding: "10px",
  borderRadius: "10px",
  marginBottom: "10px",
  fontSize: "1rem",
  boxShadow: "1px 1px 1px #888"
}

const userChatBubbleStyle = css`
  ${bubbleStyle}
  align-self: flex-end;
  color: #fff;
  background-color: #007bff;
`;

const agentChatBubbleStyle = css`
  ${bubbleStyle}
  align-self: flex-start;
  background-color: #ccc;
  color: #444;
`;

let agentSessionId: string;
let lastSentUserMessage: string;
const commandHistory = new CommandHistory();

export default function SupportTickets() {
  const [userMessage, setUserMessage] = useState("");
  const [conversationHistory, setConversationHistory] = useState<any>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState<EmailInfo | undefined>(undefined);

  useEffect(() => {
    (async () => {
      setIsLoading(true);
      const sessionInfo = await axios.post(`http://${window.location.hostname}:3000/api/start-agent-session`);
      agentSessionId = sessionInfo.data.id;
      setConversationHistory([{
        type: "agent",
        message: sessionInfo.data.welcomeMessage
      }]);
      setIsLoading(false);
    })();
  }, []);

  useEffect(() => {
    const chatHistoryElement: HTMLDivElement | null = document.querySelector(`.${chatHistoryStyle}`);

    if (chatHistoryElement === null) {
      return;
    }

    chatHistoryElement.lastElementChild?.scrollIntoView();
  }, [conversationHistory])

  function addMessageToHistory(...messages: ChatMessage[]) {
    setConversationHistory([
      ...conversationHistory,
      ...messages
    ]);
  }

  function tryGetQueryResultData(responseData: any) {
    try {
      const agentResponse = JSON.parse(responseData.message.content.text);
      return agentResponse.executionResult;
    } catch {
      return null;
    }
  }

  async function handleSendEmail(requiredAction: any) {
    setEmail(
      JSON.parse(requiredAction.functionCall.arguments)
    );

    await axios.post(`http://${window.location.hostname}:3000/api/chat-with-agent`, {
      agentSessionId,
      userMessage: lastSentUserMessage,
      performedActions: [{
        actionId: requiredAction.actionId,
        performedActionType: "FUNCTION_CALLING_PERFORMED_ACTION",
        functionCallOutput: JSON.stringify({
          "emailSent": true
        })
      }]
    });
  }

  const handleSubmit = async () => {
    commandHistory.addCommand(userMessage);
    lastSentUserMessage = userMessage;
    addMessageToHistory({
      type: "user",
      message: lastSentUserMessage
    });

    setUserMessage("");
    setIsLoading(true);

    try {
      const response = await axios.post(`http://${window.location.hostname}:3000/api/chat-with-agent`, {
        agentSessionId,
        userMessage
      });

      const dataTable = tryGetQueryResultData(response.data);
      const chatHistoryUpdate: ChatMessage[] = [{
        type: "user",
        message: lastSentUserMessage
      }];

      if (dataTable) {
        chatHistoryUpdate.push({
          type: "agent",
          dataTable
        });
      } else if (response.data.message?.content?.text) {
        chatHistoryUpdate.push({
          type: "agent",
          message: response.data.message.content.text,
          citations: response.data.message.content.citations
        });
      } else if (response.data.requiredActions) {
        handleSendEmail(response.data.requiredActions[0]);
      } else {
        chatHistoryUpdate.push({
          type: "agent",
          message: "I'm having an issue getting the proper response, please try again"
        });
      }

      addMessageToHistory(...chatHistoryUpdate);
    } catch (error) {
      console.error(error);
      addMessageToHistory({
        type: "user",
        message: lastSentUserMessage
      }, {
        type: "agent",
        message: "Failed to send message... please try again."
      });
    }

    setIsLoading(false);
  };

  function handleKey(event: KeyboardEvent<HTMLInputElement>) {
    switch (event.code) {
      case "Enter":

        handleSubmit();
        break;

      case "ArrowUp":

        setUserMessage(commandHistory.prevCommand());
        break;

      case "ArrowDown":

        setUserMessage(commandHistory.nextCommand());
        break;
    }
  }

  function handleEmailSent() {
    setEmail(undefined);
  }

  return (
    <div className={pageStyle}>
      <div className={chatBoxStyle}>
        <div className={chatHistoryStyle}>
          {conversationHistory.map((message: ChatMessage, index: number) => (
            <div
              key={index}
              className={message.type === "user" ? userChatBubbleStyle : agentChatBubbleStyle}
            >
              {
                !message.message ? (
                  message.dataTable?.length === 1 ?
                    <Record dataTable={message.dataTable} /> :
                    <DataTable dataTable={message.dataTable} />
                ) : <TextResponse message={message} />
              }
            </div>
          ))}
        </div>
        <div className={chatInputContainerStyle}>
          <input
            type="text"
            value={userMessage}
            onChange={(event) => setUserMessage(event.target.value)}
            placeholder="Type a message..."
            className={chatInputStyle}
            onKeyUp={handleKey}
            disabled={isLoading}
          />
          {
            isLoading ?
              <LoadingSpinner /> :
              <button
                type="button"
                className={chatButtonStyle}
                onClick={handleSubmit}
                disabled={isLoading}
              >
                <div>
                  ✨
                </div>
              </button>
          }
        </div>
      </div>
      {
        email &&
        <Email
          email={email}
          onSent={handleEmailSent}
        />
      }
    </div>
  );
}