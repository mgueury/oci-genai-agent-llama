export type AvatarSizes = "16x16" | "24x24" | "32x32" | "48x48";

export interface Ticket {
  id: number,
  fields: {
    summary: string;
    assignee: {
      displayName: string;
      emailAddress: string;
      avatarUrls: {
        [size in AvatarSizes]: string
      }
    },
    priority: {
      name: string;
      iconUrl: string;
    },
    status: {
      name: string;
    }
  }
}
