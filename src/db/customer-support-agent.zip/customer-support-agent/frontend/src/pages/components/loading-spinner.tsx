import { css } from "@linaria/core";

const loadingSpinnerStyle = css`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 5rem;

    .spinner {
      animation: rotate 2s linear infinite;
      height: 2rem;
      width: 2rem;
      margin: 0 auto;
    }

    .path {
      stroke-dasharray: 187;
      stroke-dashoffset: 0;
      stroke-linejoin: round;
      stroke-width: 6;
      stroke: #3498db;
      stroke-opacity: 1;
      animation: dash 1.5s ease-in-out infinite;
    }

    @keyframes rotate {
      100% {
        transform: rotate(360deg);
      }
    }

    @keyframes dash {
      0% {
        stroke-dasharray: 1, 200;
        stroke-dashoffset: 0;
      }

      50% {
        stroke-dasharray: 90, 150;
        stroke-dashoffset: -35;
      }

      100% {
        stroke-dasharray: 90, 150;
        stroke-dashoffset: -124;
      }
    }
`;

export default function LoadingSpinner() {
  return (
    <div className={loadingSpinnerStyle}>
      <svg
        className="spinner"
        viewBox="0 0 66 66"
      >
        <circle
          className="path"
          fill="none"
          strokeWidth="6"
          strokeLinecap="round"
          cx="33"
          cy="33"
          r="30"
        />
      </svg>
    </div>
  );
}