import { JSX } from "react";
import { css } from "@linaria/core";

interface Props {
  dataTable?: object[] | undefined;
}

const tableStyle = css`
  th {
    background-color: #ddd;
    color: #666;
    white-space: nowrap;
    padding: 0.5rem;
  }

  td {
    background-color: #eee;
    padding: 0.5rem;
    vertical-align: top;
  }
`;

export default ({ dataTable }: Props): JSX.Element | null => {
  if (!Array.isArray(dataTable) || dataTable.length === 0) {
    return <>No data returned</>
  }

  return (
    <table className={tableStyle}>
      <thead>
        <tr>
          {Object.keys(dataTable[0]!).map((header: string, index: number) => (
            <th key={index}>{header}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {dataTable.map((dataRow: any, index: number) => (
          <tr key={index}>
            {Object.keys(dataRow).map((key: string, index: number) => (
              <td key={index}>{dataRow[key]}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}