import { JSX } from "react";
import { css } from "@linaria/core";

interface Props {
  dataTable?: any[] | undefined;
}

const tableStyle = css`
  .title {
    background-color: #ddd;
    color: #666;
    white-space: nowrap;
    padding: 0.5rem;
    font-weight: bold;
  }

  .value {
    padding: 0.5rem;
    background-color: #eee;
  }
`;

export default ({ dataTable }: Props): JSX.Element | null => {
  if (!Array.isArray(dataTable) || dataTable.length !== 1) {
    return null;
  }

  return (
    <table className={tableStyle}>
      <tbody>
        {Object.keys(dataTable[0]!).map((key: string, index: number) => (
          <tr key={index}>
            <td className="title">{key}</td>
            <td className="value">{dataTable[0][key]}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}