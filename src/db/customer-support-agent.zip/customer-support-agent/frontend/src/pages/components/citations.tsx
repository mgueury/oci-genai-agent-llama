import { useState } from "react";
import { css } from "@linaria/core";
import Markdown from "markdown-to-jsx";

import { Citation } from "../agent-chat";
import ChevronIcon from "./chevron-icon";

interface Props {
  citations?: Citation[] | undefined;
}

const citationsStyle = css`
  button {
    font-size: 1rem;
    font-weight: bold;
    background: transparent;
    border: 0;
    margin: 0;
    padding: 0;
  }

  .citations {
    transition: transform 0.2s ease-in-out;
    display: none;
  }

  .show-citations {
    display: block !important;
  }
`;

function getSourceDocumentUrl(citation: Citation): string {
  return citation.sourceLocation.url.replace(
    "https://objectstorage.us-chicago-1.oraclecloud.com/n/axk4z7krhqfx/b/customer-support-knowledge-articles/o/",
    "https://objectstorage.us-chicago-1.oraclecloud.com/p/CtKZ8Zi9ofIy6Pe8fEE4UXUwnRP57iSRFeJxho-XBkiU1UTCV1IMIaYGkIrod5pP/n/axk4z7krhqfx/b/customer-support-knowledge-articles/o/"
  );
}

export default ({ citations }: Props) => {
  const [isOpen, setIsOpen] = useState(false);

  if (!Array.isArray(citations) || citations.length === 0) {
    return;
  }

  function handleIsOpen() {
    setIsOpen(!isOpen);
  }

  return (
    <div className={citationsStyle}>
      <button onClick={handleIsOpen}>
        <ChevronIcon isOpen={isOpen} />
        Citations
      </button>
      <div className={`citations ${isOpen ? "show-citations" : ""}`}>
        {citations.map((citation, index) => (
          <div key={index}>
            <Markdown>{citation.sourceText}</Markdown>
            <a
              href={getSourceDocumentUrl(citation)}
              target="_blank"
            >
              {citation.title || "Source document"}
            </a>
            <br />
            <b>Page numbers: {citation.pageNumbers.join(", ")}</b>
          </div>
        ))}
      </div>
    </div>
  );
}
