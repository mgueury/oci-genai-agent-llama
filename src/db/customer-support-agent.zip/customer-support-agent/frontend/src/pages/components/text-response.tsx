import Markdown from "markdown-to-jsx";
import { ChatMessage } from "../agent-chat";
import Citations from "./citations";

interface Props {
  message: ChatMessage;
}

export default ({ message }: Props) => (
  <div>
    <Markdown>{message.message!}</Markdown>
    <Citations citations={message.citations} />
  </div>
);