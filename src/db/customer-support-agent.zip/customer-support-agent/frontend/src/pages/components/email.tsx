import { css } from "@linaria/core";
import { useState } from "react";

export interface EmailInfo {
  customerEmail: string;
  subject: string;
  emailBodyContent: string;
}

interface Props {
  email: EmailInfo;
  onSent: () => void;
}

const emailStyle = css`
  position: absolute;
  display: flex;
  justify-self: center;
  flex-direction: column;
  box-sizing: border-box;
  top: 1rem;
  left: 50%;
  right: 50%;
  padding: 1rem;
  gap: 0.5rem;
  width: 30rem;
  height: 35rem;
  background-color: #f6f7f9;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  box-shadow: 1px 1px 1px #333;
  font-size: 1rem;
  overflow: hidden;

  h1 {
    display: flex;
    align-self: center;
    margin: 0;
  }

  input {
    font-size: 1rem;
    width: 100%;
    border-radius: 0.5rem;
    border: 1px solid rgb(228, 228, 231);
    background-color: #fff;
    box-sizing: border-box;
    padding: 0.5rem;
    font-family: arial;
  }

  textarea {
    font-size: 1rem;
    border: 0;
    width: 100%;
    border-radius: 0.5rem;
    box-sizing: border-box;
    padding: 0.5rem;
    height: 100%;
    border: 1px solid rgb(228, 228, 231);
    background-color: #fff;
    font-family: arial;
  }

  button {
    background-color: #000;
    color: #fff;
    padding: 0.5rem;
    border: 0;
    border-radius: 0.5rem;
    font-size: 1rem;
  }
`;

const sendAnimationStyle = css`
  animation-name: send;
  animation-duration: 1s;

  @keyframes send {
    from {
      transform: scale(1) translateX(0);
    }

    to {
      transform: scale(0.01) translateX(200%);
    }
  }
`;

export default ({ email, onSent }: Props) => {
  const [isSend, setIsSend] = useState(false);

  function handleSend() {
    setIsSend(true);
    setTimeout(onSent, 900);
  }

  return (
    <div className={`${emailStyle} ${isSend ? sendAnimationStyle : ""}`}>
      <h1>Send Email</h1>
      <div><b>To</b></div>
      <div>
        <input
          type="email"
          value={email.customerEmail}
        />
      </div>
      <div><b>Subject</b></div>
      <div>
        <input
          type="email"
          value={email.subject}
        />
      </div>
      <textarea defaultValue={email.emailBodyContent} />
      <button onClick={handleSend}>Send Email</button>
    </div>
  );
}