export default class CommandHistory {
  private history: string[];
  private currentIndex: number;

  constructor() {
    this.history = [];
    this.currentIndex = -1;
  }

  public addCommand(command: string): void {
    this.history.push(command);
    this.currentIndex = this.history.length;
  }

  public prevCommand(): string {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }

    return this.history[this.currentIndex]!;
  }

  public nextCommand(): string {
    if (this.currentIndex < this.history.length - 1) {
      this.currentIndex++;
    }

    return this.history[this.currentIndex]!;
  }

  public getCurrentCommand(): string {
    if (this.currentIndex !== -1) {
      return this.history[this.currentIndex]!;
    } else {
      return "";
    }
  }

  public clearHistory(): void {
    this.history = [];
    this.currentIndex = -1;
  }
}
