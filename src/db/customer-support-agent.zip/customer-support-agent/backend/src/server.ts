require("dotenv").config();

import http from "http";
import fs from "fs";

import express, { Application } from "express";
import cors from "cors";

import chatWithAgent from "./routes/chat-with-agent";
import startAgentSession from "./routes/start-agent-session";

class Server {
  private readonly app: Application;
  private httpsServer: http.Server | undefined;

  constructor(
  ) {
    this.app = express();
    this.app.use(cors());
    this.configureMiddleware();
    this.configureRoutes();
  }

  private configureMiddleware() {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
  }

  private configureRoutes(): void {
    this.app.post("/api/start-agent-session", startAgentSession);
    this.app.post("/api/chat-with-agent", chatWithAgent);
  }

  public async start(): Promise<void> {
    this.createHttpsServer();
    await this.startListening();
    this.handleShutdown();
  }

  private createHttpsServer() {
    this.httpsServer = http.createServer(this.app);
  }

  private async startListening(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.httpsServer!.listen(parseInt(process.env.PORT!), () => {
        console.log(`Server started on port ${process.env.PORT}`);
        resolve();
      });

      this.httpsServer!.on("error", (error) => {
        console.error(`Error starting server: ${error.message}`);
        reject(error);
      });
    });
  }

  private handleShutdown() {
    process.on("SIGINT", () => {
      console.log("Stopping server...");
      this.httpsServer!.close(() => {
        console.log("Server stopped.");
        process.exit(0);
      });
    });
  }
}

(async () => {
  try {
    const server = new Server();
    await server.start();
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
})();