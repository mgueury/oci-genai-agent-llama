import { RequestOptions, request as httpsRequest } from "https";
import { ClientRequest, IncomingMessage } from "http";
import { HttpsProxyAgent } from "https-proxy-agent";

import {
  DefaultRequestSigner,
  HttpRequest,
  AuthenticationDetailsProvider,
  ConfigFileAuthenticationDetailsProvider
} from "oci-common";

type SimpleHeaders = {
  [headerName: string]: string;
}

export default class {
  public static async post<RequestType, ResponseType>(
    request: RequestType,
    uri: string,
    useProxy: boolean = false
  ): Promise<ResponseType> {
    const headers = new Headers({ "Content-Type": "application/json" });
    const httpRequest: HttpRequest = {
      uri,
      headers: headers,
      method: "POST",
      body: JSON.stringify(request)
    };

    if (useProxy) {
      return await this.makeRequestWithProxy(httpRequest);
    } else {
      return await this.makeRequest(httpRequest);
    }
  }

  public static async get<ResponseType>(uri: string, useProxy: boolean = false): Promise<ResponseType> {
    const headers = new Headers({ "Content-Type": "application/json" });
    const httpRequest: HttpRequest = {
      uri,
      headers: headers,
      method: "GET"
    };

    if (useProxy) {
      return await this.makeRequestWithProxy(httpRequest);
    } else {
      return await this.makeRequest(httpRequest);
    }
  }

  private static async makeRequest<ResponseType>(httpRequest: HttpRequest): Promise<ResponseType> {
    await this.signRequest(httpRequest);

    const response = await fetch(
      new Request(httpRequest.uri, {
        method: httpRequest.method,
        headers: httpRequest.headers,
        body: httpRequest.body
      })
    );

    if (response.ok) {
      return await response.json();
    } else {
      throw new Error(
        JSON.stringify({
          url: httpRequest.uri,
          method: httpRequest.method,
          status: response.status,
          statusText: response.statusText,
          body: await response.text()
        })
      )
    }
  }

  private static async makeRequestWithProxy<ResponseType>(httpRequest: HttpRequest): Promise<ResponseType> {
    await this.signRequest(httpRequest);

    return new Promise((resolve, reject) => {
      try {
        const request: ClientRequest = httpsRequest(
          this.getHttpsRequestOptions(httpRequest),
          (response: IncomingMessage) => this.handleHttpRequestPromise(
            httpRequest.uri,
            response,
            resolve,
            reject
          )
        );

        request.on("error", (error: unknown) => {
          reject(new Error(
            JSON.stringify(error)
          ));
        });

        request.write(httpRequest.body);
        request.end();
      } catch (error) {
        throw new Error(
          JSON.stringify(error)
        );
      }
    });
  }

  private static async signRequest(httpRequest: HttpRequest): Promise<void> {
    const provider: AuthenticationDetailsProvider = new ConfigFileAuthenticationDetailsProvider(undefined, process.env.AUTHENTICATION_PROFILE!);
    const signer = new DefaultRequestSigner(provider);
    await signer.signHttpRequest(httpRequest);
  }

  private static getHttpsRequestOptions(httpRequest: HttpRequest): RequestOptions {
    const agent = new HttpsProxyAgent(process.env.HTTPS_PROXY_URL!);
    const url = new URL(httpRequest.uri);

    return {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: httpRequest.method,
      headers: this.convertHeadersToSimpleHeaders(httpRequest.headers),
      agent
    };
  }

  private static convertHeadersToSimpleHeaders(headers: Headers): SimpleHeaders {
    const simpleHeaders: SimpleHeaders = {};

    for (const header of headers) {
      simpleHeaders[header[0]] = header[1];
    }

    return simpleHeaders;
  }

  private static handleHttpRequestPromise = <ResponseType>(
    requestUrl: string,
    response: IncomingMessage,
    resolve: (value: ResponseType | PromiseLike<ResponseType>) => void,
    reject: (reason?: any) => void
  ): void => {
    response.setEncoding("utf-8");
    const responseData: string[] = [];

    response.on("data", (chunk: string) => responseData.push(chunk));
    response.on("end", () => this.handleHttpRequestEnd(
      responseData.join(),
      response,
      requestUrl,
      resolve,
      reject,
    ));
  }

  private static handleHttpRequestEnd<ResponseType>(
    responseData: string,
    response: IncomingMessage,
    requestUrl: string,
    resolve: (value: ResponseType | PromiseLike<ResponseType>) => void,
    reject: (reason?: any) => void,
  ): void {
    if (response.statusCode! / 100 !== 2) {
      reject(
        new Error(
          JSON.stringify({
            apiUrl: requestUrl,
            status: response.statusCode,
            statusText: response.statusMessage,
            body: responseData,
            headers: response.headers
          })
        )
      );
    } else {
      try {
        const responseJson: ResponseType = JSON.parse(responseData);
        resolve(responseJson);
      } catch (error) {
        console.log(error);
        reject(
          new Error(
            JSON.stringify(error)
          )
        );
      }
    }
  }
}
