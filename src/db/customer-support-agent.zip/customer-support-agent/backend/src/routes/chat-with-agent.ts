import { Request, Response } from "express";
import * as Joi from "joi";

import OciRequestHelper from "../utils/oci-request-helper";

interface ChatWithAgentParameters {
  agentSessionId: string;
  userMessage: string;
  performedActions: [];
}

const chatWithAgentSchema = Joi.object<ChatWithAgentParameters>().keys({
  agentSessionId: Joi.string(),
  userMessage: Joi.string().optional(),
  performedActions: Joi.array().items(Joi.object().keys({
    actionId: Joi.string(),
    performedActionType: Joi.string(),
    functionCallOutput: Joi.string()
  })).optional()
});

export default async function chatWithAgent(req: Request, res: Response): Promise<void> {
  try {
    const parameters: ChatWithAgentParameters | null = validateParameters(req);

    if (parameters === null) {
      res.status(400).send('Invalid request body');
      return;
    }

    const response: any = await OciRequestHelper.post(
      {
        sessionId: parameters.agentSessionId,
        userMessage: parameters.userMessage,
        shouldStream: false,
        performedActions: parameters.performedActions
      },
      `https://agent-runtime.generativeai.us-chicago-1.oci.oraclecloud.com/20240531/agentEndpoints/${process.env.AGENT_ENDPOINT_OCID!}/actions/chat`,
      (process.env.USE_PROXY === "1")
    );

    res.set("Cache-Control", "no-cache, no-store, must-revalidate");
    res.status(200).json(response);
  } catch (error) {
    console.error(error);
    res.status(500).send("Failed to retrieve communicate with agent");
  }
}
function validateParameters(req: Request): ChatWithAgentParameters | null {
  const { error, value } = chatWithAgentSchema.validate(req.body);
  return error ? null : value;
}