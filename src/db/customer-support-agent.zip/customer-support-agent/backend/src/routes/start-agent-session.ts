import { Request, Response } from "express";

import OciRequestHelper from "../utils/oci-request-helper";

interface SessionInfo {
  id: string;
  displayName: string;
  description: string;
  welcomeMessage: string;
  timeCreated: string;
  timeUpdated: string;
}

export default async function startAgentSession(_req: Request, res: Response): Promise<void> {
  try {
    const response: SessionInfo = await OciRequestHelper.post(
      {},
      `https://agent-runtime.generativeai.us-chicago-1.oci.oraclecloud.com/20240531/agentEndpoints/${process.env.AGENT_ENDPOINT_OCID!}/sessions`,
      (process.env.USE_PROXY === "1")
    );

    res.set("Cache-Control", "no-cache, no-store, must-revalidate");
    res.status(200).json(response);
  } catch (error) {
    console.error(error);
    res.status(500).send("Failed to retrieve communicate with agent");
  }
}